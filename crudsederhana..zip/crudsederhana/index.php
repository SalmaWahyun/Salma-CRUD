<?php
require_once 'header.php';
?>

<div class="container">
    <div class="jumbotron">

        <h1>Aspirasi Mahasiswa Politeknik Negeri Madiun</h1>
        <p>Selamat Datang di website jaring Aspirasi Mahasiswa Politeknik Negeri Madiun.
        Aspirasi Mahasiswa adalah kegiatan yang sengaja diadakan untuk menampung dan menyalurkan aspirasi dari 
        seluruh mahasiswa Politeknik Negeri Madiun baik berupa gagasan, kritik, maupun saran kepada jajaran rektorat 
        untuk ditindak lanjuti guna menunjang kemajuan Politeknik Negeri Madiun. Mohon diisi dengan sebaik mungkin. Terima kasih</p>
    </div>
</div>

<?php
require_once 'footer.php';
?>